# Structure-from-motion-python
Implementation based on SFMedu Princeton COS429: Computer Vision http://vision.princeton.edu/courses/SFMedu/ but on python + numpy

The objective of this project was to understand  the structure from motion problem so i take the MATLAB code from http://vision.princeton.edu/courses/SFMedu/
and translate it in python + numpy. The initial version is just a literal translation from the MATLAB code to python (so expect higher run times, if you want a fast and easy to use software see http://ccwu.me/vsfm/)

Requeriments
Numpy, cv2, https://github.com/dranjan/python-plyfile

For an example just run main.py without any changes. It will generate a point cloud of a jirafe from 5 images included in examples folder. (can take up to 30 m)


OUTPUT
/Users/admin/Desktop/CTO/Structure-from-motion-python/utils/graph.py:84: VisibleDeprecationWarning: using a non-integer number instead of an integer will result in an error in the future
  x[cnt,:] = newGraph.obsVal[newGraph.ObsIdx[i][ind],:]
('Error inicial de ', 9.9789889538788508)
('Error despues de optimizar de ', 0.50747511935620537)
('SIFT ha generado para A,B ', 969, 1227, ' descriptores')
('Muy pocos puntos de match se relajara la tolerancia a', 0.7, ' habian ', 2)
('Muy pocos puntos de match se relajara la tolerancia a', 0.8, ' habian ', 2)
('Muy pocos puntos de match se relajara la tolerancia a', 0.9, ' habian ', 2)
('Muy pocos puntos de match se relajara la tolerancia a', 0.999, ' habian ', 2)
('Muy pocos puntos de match se relajara la tolerancia a', 2, ' habian ', 2)
Traceback (most recent call last):
  File "/Users/admin/Desktop/CTO/Structure-from-motion-python/main.py", line 80, in <module>
    keypointsA,keypointsB = getPairSIFT(listaImages[i],listaImages[i+1],show=debug)
  File "/Users/admin/Desktop/CTO/Structure-from-motion-python/utils/paresDescript.py", line 117, in getPairSIFT
    indI,indJ = algoritmoMatch(desA,desB)
  File "/Users/admin/Desktop/CTO/Structure-from-motion-python/utils/paresDescript.py", line 86, in algoritmo2Match
    " el minimo es ", minNeighboringMatching)
Exception: ('No se lograron cantidad minima de minNeighboringMatching se lograron ', 2, ' el minimo es ', 15)
admin@Mohans-Macbook-Pro Structure-from-motion-python % 


pip list
DEPRECATION: Python 2.7 will reach the end of its life on January 1st, 2020. Please upgrade your Python as Python 2.7 won't be maintained after that date. A future version of pip will drop support for Python 2.7. More details about Python 2 support in pip, can be found at https://pip.pypa.io/en/latest/development/release-process/#python-2-support
Package               Version     
--------------------- ------------
cycler                0.10.0      
matplotlib            1.5.3       
numpy                 1.11.1      
opencv-contrib-python 3.4.2.16    
pip                   19.2.3      
plyfile               0.7         
pyparsing             2.4.7       
python-dateutil       2.8.2       
pytz                  2023.3.post1
scipy                 1.2.1       
setuptools            41.2.0      
six                   1.16.0      
WARNING: You are using pip version 19.2.3, however version 20.3.4 is available.
You should consider upgrading via the 'pip install --upgrade pip' command.
